The first file called savings_calculator.m will tell you with an interest rate of 6.25%/year compounded monthly, if you have saved enough money for a 4-year degree at the U of A in either the arts, science, or engineering faculties

The second file called minimum_monthly_payment.m will tell you the minimum amount you need to save each month to afford a degree at the U of A with the same compound interest and same faculties.

(Please run the .m file in MATLAB (anything on or past version 2019a in order to avoid any potential complications))